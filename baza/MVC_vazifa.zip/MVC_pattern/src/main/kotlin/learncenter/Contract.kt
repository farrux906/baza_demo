package learncenter

import learncenter.model.Student

interface Contract {

    interface  View{
        fun add():Student
        fun delete():Student
        fun update():Pair<Student,Student>
        fun getAll(list:List<Student>)
        fun search():String
    }
    interface Controller{
        fun start()
        fun add()
        fun delete()
        fun update()
        fun getAll()
        fun search()
    }
    interface Model{
        fun add(student: Student)
        fun delete(student: Student)
        fun update(student:Pair<Student,Student>)
        fun getAll():List<Student>
        fun search(name:String):List<Student>
    }
}