import learncenter.Contract
import learncenter.controller.StudentController
import java.util.Scanner


fun main(args: Array<String>) {

    val controller:Contract.Controller=StudentController()

    controller.start()
}