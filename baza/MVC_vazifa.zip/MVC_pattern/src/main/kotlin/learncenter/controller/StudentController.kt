package learncenter.controller

import learncenter.Contract
import learncenter.model.Student
import learncenter.model.StudentModel
import learncenter.view.StudentView
import java.util.*

class StudentController:Contract.Controller {


   private val view:Contract.View=StudentView()
   private val model:Contract.Model=StudentModel()

    override fun start() {
        val scanner= Scanner(System.`in`)

        var start=true
        while (start){
            println("1-> qo'shish 2-> o'chirish 3-> yangilash, 4-> ro'yxat 5-> qidirish, 6-> chiqish ")

            when(scanner.next()){
                "1"->{
                    this.add()
                }
                "2"->{
                    this.delete()
                }
                "3"->{
                    this.update()
                }
                "4"->{
                    this.getAll()
                }
                "5"->{
                    this.search()
                }
                "6"->{
                    start =false
                }
            }
        }
    }
    override fun add() {
        model.add(view.add())
    }

    override fun delete() {
        model.delete(view.delete())
    }

    override fun update() {
        model.update(view.update())
    }

    override fun getAll() {
        view.getAll(model.getAll())
    }

    override fun search() {
        view.getAll(model.search(view.search()))
    }
}