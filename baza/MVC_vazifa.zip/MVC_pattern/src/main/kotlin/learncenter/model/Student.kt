package learncenter.model

data class Student(
    var name:String,
    var age:Int,
    var course:String
)
