package learncenter.model

import learncenter.Contract

class StudentModel:Contract.Model {

    private val studentList=ArrayList<Student>()

    override fun add(student: Student) {
        studentList.add(student)
        println("${student.name} qo'shildi")
    }

    override fun delete(student: Student) {
        if (studentList.remove(student)){
            println("${student.name} o'chirildi")
        }else{
            println("${student.name} o'chirilmadi")
        }
    }

    override fun update(students:Pair<Student,Student>) {
        var updated=false
        for (index in 0 until  studentList.size){
            if(studentList[index].name==students.first.name && studentList[index].age==students.first.age && studentList[index].course==students.first.course){
              studentList[index]=students.second
                println(students.first.name + "yangilandi")
                return
            }else{
                updated=false
            }
        }
        if(!updated){
            println(students.first.name + "yangilanmadi")
        }
    }

    override fun getAll(): List<Student> {
        return  studentList
    }

    override fun search(name: String):List<Student> {
        val newStudentList=ArrayList<Student>()
      for (student in studentList){
          if (student.name==name){
              newStudentList.add(student)
          }
      }
        return newStudentList
    }
}