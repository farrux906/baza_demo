package learncenter.view

import learncenter.Contract
import learncenter.model.Student
import java.util.Scanner

class StudentView:Contract.View {
    private val scanner=Scanner(System.`in`)
    override fun add(): Student {
        println("O'quvchi qo'shish:")
        println("Ismi:")
        val name=scanner.next()
        println("Yoshi:")
        val age=scanner.nextInt()
        println("Kurs nomi:")
        val course=scanner.next()
        return Student(name,age, course)
    }

    override fun delete(): Student {
        println("o'chirish")
        println("Ismi:")
        val name=scanner.next()
        println("Yoshi:")
        val age=scanner.nextInt()
        println("Kurs nomi:")
        val course=scanner.next()
        return Student(name,age, course)
    }

    override fun update():Pair<Student,Student> {
        println("Update")
        println("Eski ma'lumotlarni kiriting:")
        println("ismi:")
        val name1=scanner.next()
        println("yoshi:")
        val age1=scanner.nextInt()
        println("kursi:")
        val course1=scanner.next()
        println("Yangi ma'lumotlarni kiriting:")
        println("ismi:")
        val name2=scanner.next()
        println("yoshi:")
        val age2=scanner.nextInt()
        println("kursi:")
        val course2=scanner.next()
        return Pair(Student(name1,age1, course1), Student(name2,age2,course2))
    }

    override fun getAll(list: List<Student>) {
        if (list.isEmpty()){
            println("Ro'yhat bo'sh ")
            return
        }
        println("O'quvchilar ro'yhati")
        for (student in list){
            printStudent(student)
        }
    }

    override fun search(): String {
        println("Qidirish:")
        println("Ismi:")
        val name=scanner.next()
        return name
    }


    private  fun printStudent(student: Student){
        println("ismi: ${student.name}\n" +
                "yoshi: ${student.age} da\n" +
                "kursi: ${student.course}\n")
    }
}