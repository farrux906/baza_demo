package com.example.retrofit03.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter

import androidx.recyclerview.widget.RecyclerView
import com.example.retrofit03.R
import com.example.retrofit03.model.PostDto

class PostAdapter(private val listener : Callback) : ListAdapter<PostDto, PostAdapter.PostHolder>(
    object : DiffUtil.ItemCallback<PostDto>() {
        override fun areItemsTheSame(oldItem: PostDto, newItem: PostDto) = oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: PostDto, newItem: PostDto) =
            oldItem.title == newItem.title

    }) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.post_item,parent,false)
        return PostHolder(view)
    }

    override fun onBindViewHolder(holder: PostHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class PostHolder(private val view: View) : RecyclerView.ViewHolder(view) {
        fun bind(dto: PostDto) {
            val title = view.findViewById<TextView>(R.id.post_title)
            val body = view.findViewById<TextView>(R.id.post_body)

            title.text = dto.title
            body.text = dto.body

            view.findViewById<CardView>(R.id.card_view).setOnClickListener {
                listener.selectPost(dto)
            }

        }
    }

    interface Callback{
        fun selectPost(dto : PostDto)
    }


}