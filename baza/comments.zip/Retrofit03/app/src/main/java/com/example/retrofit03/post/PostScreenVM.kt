package com.example.retrofit03.post

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit03.model.PostDto
import com.example.retrofit03.network.APIClient
import com.example.retrofit03.network.APIPost
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PostScreenVM : ViewModel() {

    private val apiService : APIPost = APIClient.getAPIPost()

    private val _postLiveData = MutableLiveData<PostDto>()
    val postLiveData : LiveData<PostDto> = _postLiveData

    fun loadPostById(id : Int){
        apiService.getPostById(id).enqueue(object : Callback<PostDto>{
            override fun onResponse(call: Call<PostDto>, response: Response<PostDto>) {
                if (response.isSuccessful){
                    val body : PostDto? = response.body()
                    _postLiveData.value = body
                }
            }

            override fun onFailure(call: Call<PostDto>, t: Throwable) {
                Log.d("asd", "onFailure $t")
            }

        })
    }

}