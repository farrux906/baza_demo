package com.example.retrofit03.posts

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit03.model.PostDto
import com.example.retrofit03.network.APIClient
import com.example.retrofit03.network.APIPost
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PostsScreenVM : ViewModel() {

    private val apiService : APIPost = APIClient.getAPIPost()

    private val _postLiveData = MutableLiveData<List<PostDto>>()
    val postLiveData : LiveData<List<PostDto>> = _postLiveData

    init {
        apiService.posts().enqueue(object : Callback<List<PostDto>>{
            override fun onResponse(
                call: Call<List<PostDto>>,
                response: Response<List<PostDto>>
            ) {
                if (response.isSuccessful){
                    val body : List<PostDto> ?= response.body()
                    _postLiveData.value = body!!
                }
            }

            override fun onFailure(call: Call<List<PostDto>>, t: Throwable) {
                Log.d("check","onFailure $t")
            }

        })
    }

}