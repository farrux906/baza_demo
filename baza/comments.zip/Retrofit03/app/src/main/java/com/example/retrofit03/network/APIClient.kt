package com.example.retrofit03.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object APIClient {
    private fun getRetrofit() : Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://jsonplaceholder.typicode.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun getAPIPhoto() : APIPhoto{
        return getRetrofit().create(APIPhoto::class.java)
    }

    fun getAPIPost() : APIPost{
        return getRetrofit().create(APIPost::class.java)
    }
      fun getAPIComment() : APIComment{
        return getRetrofit().create(APIComment::class.java)
    }

}