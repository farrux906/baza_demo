package com.example.retrofit03.comment.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit03.model.CommentData

import com.example.retrofit03.network.APIClient
import com.example.retrofit03.network.APIComment

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CommentsViewModel :ViewModel(){
    val commentsLiveData=MutableLiveData<List<CommentData>>()

    private val apiService : APIComment = APIClient.getAPIComment()

    init {
        apiService.comments().enqueue(object : Callback<List<CommentData>>{
            override fun onResponse(
                call: Call<List<CommentData>>,
                response: Response<List<CommentData>>
            ) {
                if (response.isSuccessful){
                    commentsLiveData.value=response.body()
                }
            }

            override fun onFailure(call: Call<List<CommentData>>, t: Throwable) {
                Log.e("error comments",call.toString())
            }

        })
    }
}