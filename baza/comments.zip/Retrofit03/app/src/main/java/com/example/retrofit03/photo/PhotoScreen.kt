package com.example.retrofit03.photo

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.example.retrofit03.R
import com.example.retrofit03.model.PhotoModel

class PhotoScreen : Fragment(R.layout.fragment_photo) {

    private lateinit var viewModel : PhotoScreenVM

    val args: PhotoScreenArgs by navArgs()

    private lateinit var photoTitle : TextView
    private lateinit var photoBody : ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this)[PhotoScreenVM::class.java]

        photoTitle = view.findViewById(R.id.photo_info)
        photoBody = view.findViewById(R.id.large_photo)


        viewModel.apply {
            photoLiveData.observe(viewLifecycleOwner, photoObserver)
        }

        viewModel.loadPhotoById(args.id)
    }

    private val photoObserver = Observer<PhotoModel>{
        photoTitle.text = it.title
        Glide.with(requireView().context)
            .load(it.url+".jpg")
            .into(photoBody)
    }

}

