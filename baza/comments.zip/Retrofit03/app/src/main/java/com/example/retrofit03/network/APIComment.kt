package com.example.retrofit03.network

import com.example.retrofit03.model.CommentData
import com.example.retrofit03.model.PhotoModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface APIComment {
    @GET("comments")
    fun comments(): Call<List<CommentData>>

    @GET("comments/{postId}")
    fun getCommentById(@Path("postId") photoId: Int): Call<CommentData>

}