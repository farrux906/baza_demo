package com.example.retrofit03.posts

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofit03.R
import com.example.retrofit03.adapter.PostAdapter
import com.example.retrofit03.model.PostDto
import com.example.retrofit03.post.PostScreen

class PostsScreen : Fragment(R.layout.fragment_posts), PostAdapter.Callback {

    private lateinit var postAdapter: PostAdapter
    private lateinit var viewModel : PostsScreenVM

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this)[PostsScreenVM::class.java]

        postAdapter = PostAdapter(this)
        val rv = view.findViewById<RecyclerView>(R.id.rv_post)
        rv.adapter = postAdapter

        viewModel.apply {
            postLiveData.observe(viewLifecycleOwner, postObserver)
        }
    }

    private val postObserver = Observer<List<PostDto>>{
        postAdapter.submitList(it)
    }

    override fun selectPost(dto: PostDto) {
        findNavController().navigate(PostsScreenDirections.actionPostScreenToPostScreen2(dto.id))
    }


}