package com.example.retrofit03.photos

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofit03.R
import com.example.retrofit03.adapter.PhotoAdapter
import com.example.retrofit03.model.PhotoModel
import com.example.retrofit03.photo.PhotoScreen
import com.example.retrofit03.posts.PostsScreenDirections

class PhotosScreen : Fragment(R.layout.fragment_photos), PhotoAdapter.CallBack {

    private lateinit var photoAdapter: PhotoAdapter
    private lateinit var viewModel : PhotosScreenVM

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this)[PhotosScreenVM::class.java]

        photoAdapter = PhotoAdapter(this)
        val rv = view.findViewById<RecyclerView>(R.id.rv_photo)
        rv.adapter = photoAdapter

        viewModel.apply {
            photoLiveData.observe(viewLifecycleOwner, photoObserver)
        }
    }

    private val photoObserver = Observer<List<PhotoModel>>{
        photoAdapter.submitList(it)
    }


    override fun selectPhoto(model: PhotoModel) {
        findNavController().navigate(PhotosScreenDirections.actionPhotoScreenToPhotoScreen2(model.id))
    }


}