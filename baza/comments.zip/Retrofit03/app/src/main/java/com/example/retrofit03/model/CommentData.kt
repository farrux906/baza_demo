package com.example.retrofit03.model

data class CommentData(
    val body: String,
    val email: String,
    val id: Int,
    val name: String,
    val postId: Int
)