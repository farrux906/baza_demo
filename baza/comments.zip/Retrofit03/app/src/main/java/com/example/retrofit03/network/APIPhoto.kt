package com.example.retrofit03.network

import com.example.retrofit03.model.PhotoModel
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface APIPhoto {

    @GET("photos")
    fun photos(): Call<List<PhotoModel>>

    @GET("photos/{id}")
    fun getPhotoById(@Path("id") photoId: Int): Call<PhotoModel>

}