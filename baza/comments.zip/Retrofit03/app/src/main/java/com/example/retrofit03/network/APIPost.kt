package com.example.retrofit03.network

import com.example.retrofit03.model.PhotoModel
import com.example.retrofit03.model.PostDto
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface APIPost {
    @GET("posts")
    fun posts(): Call<List<PostDto>>

    @GET("posts/{id}")
    fun getPostById(@Path("id") postId: Int): Call<PostDto>
}
