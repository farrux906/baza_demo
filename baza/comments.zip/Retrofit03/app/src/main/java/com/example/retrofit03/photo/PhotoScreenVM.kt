package com.example.retrofit03.photo

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit03.model.PhotoModel
import com.example.retrofit03.network.APIClient
import com.example.retrofit03.network.APIPhoto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PhotoScreenVM : ViewModel() {

    private val apiService : APIPhoto = APIClient.getAPIPhoto()

    private val _photoLiveData = MutableLiveData<PhotoModel>()
    val photoLiveData : LiveData<PhotoModel> = _photoLiveData

    fun loadPhotoById(id : Int){
        apiService.getPhotoById(id).enqueue(object : Callback<PhotoModel>{
            override fun onResponse(call: Call<PhotoModel>, response: Response<PhotoModel>) {
                if (response.isSuccessful){
                    val body : PhotoModel? = response.body()
                    _photoLiveData.value = body!!
                }
            }

            override fun onFailure(call: Call<PhotoModel>, t: Throwable) {
                Log.d("asd", "onFailure $t")
            }

        })
    }

}