package com.example.retrofit03.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.retrofit03.R
import com.example.retrofit03.model.PhotoModel

class PhotoAdapter(private val listener : CallBack) : ListAdapter<PhotoModel, PhotoAdapter.PhotoHolder>(
    object : DiffUtil.ItemCallback<PhotoModel>(){
        override fun areItemsTheSame(oldItem: PhotoModel, newItem: PhotoModel): Boolean {
            return oldItem == newItem
        }

        override fun areContentsTheSame(oldItem: PhotoModel, newItem: PhotoModel): Boolean {
            return oldItem.id == newItem.id
        }

    }
) {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoHolder {
        val inflater = LayoutInflater.from(parent.context).inflate(R.layout.photo_item,parent,false)
        return PhotoHolder(inflater)
    }

    override fun onBindViewHolder(holder: PhotoHolder, position: Int) {
        holder.bind(getItem(position))

    }

    inner class PhotoHolder(private val view: View) : RecyclerView.ViewHolder(view){
        fun bind(model: PhotoModel){
            val photo = view.findViewById<ImageView>(R.id.photo)
            val title = view.findViewById<TextView>(R.id.title)

            Glide.with(view.context)
                .load(model.thumbnailUrl+".jpg")
                .into(photo)

            Log.d("photo","${model.thumbnailUrl} ")

            title.text = model.title

            view.findViewById<CardView>(R.id.card_view).setOnClickListener {
                listener.selectPhoto(model)
            }
        }
    }

    interface CallBack{
        fun selectPhoto(model : PhotoModel)
    }

}