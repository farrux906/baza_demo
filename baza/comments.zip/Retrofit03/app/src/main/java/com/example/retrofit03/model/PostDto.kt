package com.example.retrofit03.model

data class PostDto(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)