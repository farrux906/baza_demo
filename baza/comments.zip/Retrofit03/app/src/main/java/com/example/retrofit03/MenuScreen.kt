package com.example.retrofit03

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.retrofit03.databinding.MenuFragmentBinding
import com.example.retrofit03.photos.PhotosScreen
import com.example.retrofit03.posts.PostsScreen

class MenuScreen : Fragment(R.layout.menu_fragment){


    private val binding:MenuFragmentBinding by viewBinding()


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        binding.users.setOnClickListener {
            Toast.makeText(requireContext(), "Users", Toast.LENGTH_SHORT).show()
        }

        binding.albums.setOnClickListener {

            Toast.makeText(requireContext(), "Albums", Toast.LENGTH_SHORT).show()

        }

        binding.posts.setOnClickListener {
            findNavController().navigate(MenuScreenDirections.actionMenuScreenToPostScreen())
        }

        binding.photos.setOnClickListener {
            findNavController().navigate(MenuScreenDirections.actionMenuScreenToPhotoScreen())
        }

        binding.comments.setOnClickListener {
            findNavController().navigate(MenuScreenDirections.actionMenuScreenToCommentsFragment())
        }
    }


}