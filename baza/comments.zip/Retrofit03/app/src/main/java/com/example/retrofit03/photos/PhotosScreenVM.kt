package com.example.retrofit03.photos

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.retrofit03.model.PhotoModel
import com.example.retrofit03.network.APIClient
import com.example.retrofit03.network.APIPhoto
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PhotosScreenVM : ViewModel() {

    private val apiService : APIPhoto = APIClient.getAPIPhoto()

    private val _photoLiveData = MutableLiveData<List<PhotoModel>>()
    val photoLiveData : LiveData<List<PhotoModel>> = _photoLiveData

    init {
        apiService.photos().enqueue(object : Callback<List<PhotoModel>>{
            override fun onResponse(
                call: Call<List<PhotoModel>>,
                response: Response<List<PhotoModel>>
            ) {
                if (response.isSuccessful){
                    val body : List<PhotoModel> ?= response.body()
                    _photoLiveData.value = body!!
                }
            }

            override fun onFailure(call: Call<List<PhotoModel>>, t: Throwable) {
                Log.d("check","onFailure $t")
            }

        })
    }

}