package com.example.retrofit03.post

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.example.retrofit03.R
import com.example.retrofit03.model.PhotoModel
import com.example.retrofit03.model.PostDto

class PostScreen : Fragment(R.layout.fragment_post) {

    private lateinit var viewModel : PostScreenVM

    private val args:PostScreenArgs by navArgs()
    private lateinit var postTitle : TextView
    private lateinit var postBody : TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel = ViewModelProvider(this)[PostScreenVM::class.java]

        postTitle = view.findViewById(R.id.post_title)
        postBody = view.findViewById(R.id.post_body)

        viewModel.apply {
            postLiveData.observe(viewLifecycleOwner, postObserver)
        }

        viewModel.loadPostById(args.id)
    }

    private val postObserver = Observer<PostDto>{
        postTitle.text = it.title
        postBody.text = it.body

    }

}

