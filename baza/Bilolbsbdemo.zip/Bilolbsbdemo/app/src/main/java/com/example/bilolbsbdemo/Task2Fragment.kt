package com.example.bilolbsbdemo

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class Task2Fragment:Fragment(R.layout.fragment_task2)