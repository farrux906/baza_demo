package com.example.bilolbsbdemo

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class Task1Fragment:Fragment(R.layout.fragment_task1){

}