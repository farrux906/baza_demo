package com.example.bilolbsbdemo.comment

data class CommentData(
    val body: String,
    val email: String,
    val id: Int,
    val name: String,
    val postId: Int
)