package com.example.bilolbsbdemo

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.bilolbsbdemo.databinding.FragmentMainfragmentBinding


class  MainFragment: Fragment(R.layout.fragment_mainfragment){

    private val binding:FragmentMainfragmentBinding by viewBinding()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.task1Btn.setOnClickListener{
            findNavController().navigate(MainFragmentDirections.actionMainFragmentToTask1Fragment())
        }

        binding.task2Btn.setOnClickListener{
            findNavController().navigate(MainFragmentDirections.actionMainFragmentToCommentsFragment())
        }
    }
}