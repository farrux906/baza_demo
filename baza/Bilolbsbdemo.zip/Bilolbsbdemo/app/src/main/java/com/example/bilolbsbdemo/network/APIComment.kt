package com.example.bilolbsbdemo.network

import com.example.bilolbsbdemo.comment.CommentData

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface APIComment {
    @GET("comments")
    fun comments(): Call<List<CommentData>>

    @GET("comments/{postId}")
    fun getCommentById(@Path("postId") photoId: Int): Call<CommentData>

}