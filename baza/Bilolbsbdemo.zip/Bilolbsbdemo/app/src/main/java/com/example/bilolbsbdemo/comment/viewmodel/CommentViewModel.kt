package com.example.bilolbsbdemo.comment.viewmodel
import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.bilolbsbdemo.comment.CommentData
import com.example.bilolbsbdemo.network.APIClient
import com.example.bilolbsbdemo.network.APIComment

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CommentViewModel:ViewModel() {

    private val apiService : APIComment = APIClient.getAPIComment()


    val commentLiveData = MutableLiveData<CommentData>()

    fun searchById(id : Int){
        apiService.getCommentById(id).enqueue(object : Callback<CommentData>{
            override fun onResponse(call: Call<CommentData>, response: Response<CommentData>) {
                if (response.isSuccessful){
                    commentLiveData.value=response.body()
                }
            }

            override fun onFailure(call: Call<CommentData>, t: Throwable) {
                Log.e(TAG, "onFailure: ", )
            }

        })
    }
}