package com.example.bilolbsbdemo.comment.screen

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import by.kirich1409.viewbindingdelegate.viewBinding
import com.example.bilolbsbdemo.R
import com.example.bilolbsbdemo.comment.adapter.CommentAdapter
import com.example.bilolbsbdemo.comment.viewmodel.CommentsViewModel
import com.example.bilolbsbdemo.databinding.FragmentCommentsBinding


class CommentsFragment : Fragment(R.layout.fragment_comments) {

    private val viewModel: CommentsViewModel by viewModels ()
    private val binding: FragmentCommentsBinding by viewBinding()
    private val adapter: CommentAdapter by lazy { CommentAdapter ()}

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.list.adapter=adapter
        viewModel.commentsLiveData.observe(viewLifecycleOwner){
            adapter.submitList(it)
        }
        adapter.onClick { findNavController().navigate(CommentsFragmentDirections.actionCommentsFragmentToCommentFragment(it.postId)) }
    }

}