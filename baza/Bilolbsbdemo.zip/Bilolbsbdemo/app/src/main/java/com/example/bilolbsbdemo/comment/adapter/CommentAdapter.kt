package com.example.bilolbsbdemo.comment.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter

import androidx.recyclerview.widget.RecyclerView
import com.example.bilolbsbdemo.R
import com.example.bilolbsbdemo.comment.CommentData


class CommentAdapter : ListAdapter<CommentData, CommentAdapter.Holder>(itemCollback){
    private var listener:((CommentData)->Unit)?=null
    fun onClick(block:(CommentData)->Unit){listener=block}
    inner class Holder(view: View):RecyclerView.ViewHolder(view){
        private val name=view.findViewById<TextView>(R.id.name_comment)
        private val email=view.findViewById<TextView>(R.id.email_comment)
        private val body=view.findViewById<TextView>(R.id.body_comment)

        init {
            itemView.setOnClickListener { listener?.invoke(getItem(adapterPosition)) }
        }
        fun bind(position: Int){
            name.text=getItem(position).name
            email.text=getItem(position).email
            body.text=getItem(position).body

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_comments,parent,false))

    override fun onBindViewHolder(holder: Holder, position: Int)=holder.bind(position)
}

private object itemCollback:DiffUtil.ItemCallback<CommentData>() {
    override fun areItemsTheSame(oldItem: CommentData, newItem: CommentData)=oldItem.id==newItem.id

    override fun areContentsTheSame(oldItem: CommentData, newItem: CommentData)=oldItem.id==newItem.id&&oldItem.postId==newItem.postId&&oldItem.email==newItem.email&&oldItem.body==newItem.body&&oldItem.name==newItem.name

}
