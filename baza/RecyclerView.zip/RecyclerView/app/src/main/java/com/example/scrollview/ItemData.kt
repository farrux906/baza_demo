package com.example.scrollview

data class ItemData(
    val image:String,
    val name:String
)
