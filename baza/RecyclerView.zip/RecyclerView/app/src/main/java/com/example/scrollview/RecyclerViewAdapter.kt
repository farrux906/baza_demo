package com.example.scrollview

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class RecyclerViewAdapter:RecyclerView.Adapter<RecyclerViewAdapter.Holder>() {
    private val data=ArrayList<ItemData>()
    @SuppressLint("NotifyDataSetChanged")
    fun submitItem(newList:List<ItemData>){
        data.clear()
        data.addAll(newList)
        notifyDataSetChanged()
    }

    inner class Holder(view: View):RecyclerView.ViewHolder(view){

        private val image=view.findViewById<ImageView>(R.id.image)
        private val name =view.findViewById<TextView>(R.id.text)

        fun bind(){
            val item=data[adapterPosition]
            name.text=item.name
            Glide
                .with(image)
                .load(item.image)
                .centerCrop()
                .placeholder(R.drawable.mountines)
                .into(image)
        }
    }

    override fun onCreateViewHolder(farruh: ViewGroup, viewType: Int)=Holder(LayoutInflater.from(farruh.context).inflate(R.layout.simple_item_list,farruh,false))

    override fun onBindViewHolder(holder: Holder, position: Int)=holder.bind()

    override fun getItemCount()= data.size

}